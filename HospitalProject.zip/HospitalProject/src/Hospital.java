import java.sql.Date;

public class Hospital {
    private int patientID;
    private String patientName;
    private char patientGender;
    private int patientAge;
    private long patientMobileNo;
    private String disease;
    private String doctorName;

    private double fees;

    private Date registeredDate;
    private Date lastModifiedDate;

    public Hospital(int patientID, String patientName, char patientGender, int patientAge, long patientMobileNo, String disease, String doctorName, double fees, Date registeredDate, Date lastModifiedDate) {
        this.patientID = patientID;
        this.patientName = patientName;
        this.patientGender = patientGender;
        this.patientAge = patientAge;
        this.patientMobileNo = patientMobileNo;
        this.disease = disease;
        this.doctorName = doctorName;
        this.fees = fees;
        this.registeredDate = registeredDate;
        this.lastModifiedDate = lastModifiedDate;
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }


    public char getPatientGender() {
        return patientGender;
    }

    public void setPatientGender(char patientGender) {
        this.patientGender = patientGender;
    }

    public int getPatientAge() {
        return patientAge;
    }

    public void setPatientAge(int patientAge) {
        this.patientAge = patientAge;
    }

    public long getPatientMobileNo() {
        return patientMobileNo;
    }

    public void setPatientMobileNo(long patientMobileNo) {
        this.patientMobileNo = patientMobileNo;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getDisease() {
        return disease;
    }

    public void setDisease(String disease) {
        this.disease = disease;
    }

    public double getFees() {
        return fees;
    }

    public void setFees(double fees) {
        this.fees = fees;
    }

    public Date getRegisteredDate() {
        return registeredDate;
    }

    public void setRegisteredDate(Date registeredDate) {
        this.registeredDate = registeredDate;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @Override
    public String toString() {
        return "Hospital Record {" +
                "Patient ID = " + patientID +
                ", PatientName = '" + patientName + '\'' +
                ", PatientGender = " + patientGender +
                ", PatientAge = " + patientAge +
                ", PatientMobileNo = " + patientMobileNo +
                ", DoctorName = '" + doctorName + '\'' +
                ", Disease = '" + disease + '\'' +
                ", Fees = " + fees +
                ", RegisteredDate = " + registeredDate +
                ", LastModifiedDate = " + lastModifiedDate +
                '}';
    }
}
