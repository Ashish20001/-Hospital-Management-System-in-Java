import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.InputMismatchException;
import java.util.Properties;
import java.util.Scanner;

public class HospitalService {
    public static void main(String[] args) {
        try{
            Properties properties = new Properties();
            try (FileInputStream fileInputStream = new FileInputStream("connection.properties")) {
                properties.load(fileInputStream);
            } catch (IOException e) {
                System.out.println(e.getMessage());
                return;
            }

            try {
                Connection connection = DriverManager.getConnection(
                        properties.getProperty("url"),
                        properties.getProperty("username"),
                        properties.getProperty("password"));

                if (!isTableExists(connection, "hospital")) {
                    createHospitalTable(connection);
                    System.out.println("Hospital Table created.");
                } else {
                    System.out.println("Hospital Table already exists.");
                }

                HospitalController hospitalController = new HospitalController(connection);

                int choice;
                String continueChar;
                Scanner scanner = new Scanner(System.in);
                do {
                    System.out.println("\nHospital Management System:");
                    System.out.println("1. Add Patient Record");
                    System.out.println("2. Delete Patient Record");
                    System.out.println("3. Update Patient Information");
                    System.out.println("4. View All Patients");
                    System.out.println("5. Search for a Specific Patient");
                    System.out.println("6. Find Doctor");
                    System.out.println("7. Change Doctor");
                    System.out.println("8. Find Patient with Same Disease");
                    System.out.println("9. Discount in Fees");
                    System.out.println("10. Exit");

                    System.out.print("Enter your choice (1-10): ");
                    choice = scanner.nextInt();
                    scanner.nextLine();
                    hospitalController.processChoice(choice);

                    System.out.print("Do you want to continue? (y/n): ");
                    continueChar = String.valueOf(scanner.next().charAt(0));
                } while (continueChar.equalsIgnoreCase("y"));
            } catch (Exception e) {
                if (e instanceof InputMismatchException){
                    System.out.println("Invalid Input : Please Enter Valid Input");
                } else if (e instanceof SQLException) {
                    System.out.println("There is a Problem in Database Connection");
                }else{
                    System.out.println(e.getMessage());
                }
            }
        }catch(Exception excp){
            System.out.println(excp.getMessage());
        }
    }

    private static boolean isTableExists(Connection connection, String tableName) throws SQLException {
        DatabaseMetaData metaData = connection.getMetaData();
        ResultSet tables = metaData.getTables(null,null,tableName,null);
        return tables.next();
    }

    private static void createHospitalTable(Connection connection) throws SQLException {
        try (PreparedStatement preparedStatement = connection.prepareStatement("CREATE TABLE Hospital ("
                + "patientID serial NOT NULL, "
                + "patientName character varying(100) NOT NULL, "
                + "patientGender char NOT NULL, "
                + "patientAge integer NOT NULL, "
                + "patientMobileNo bigint, "
                + "disease character varying(50) NOT NULL, "
                + "doctorName character varying(100) NOT NULL, "
                + "fees double precision NOT NULL, "
                + "registeredDate date NOT NULL DEFAULT CURRENT_DATE, "
                + "lastModifiedDate date NOT NULL, "
                + "PRIMARY KEY (patientID))")) {
            preparedStatement.executeUpdate();
        }
    }

}