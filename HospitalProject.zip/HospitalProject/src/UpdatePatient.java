import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;

public class UpdatePatient {
    public void update(Connection connection, int patientIDToUpdate) throws SQLException {
        PreparedStatement preparedStatement;
        Scanner scanner = new Scanner(System.in);

        String continueChar;
        do {
            System.out.println("\nUpdate Patient : " + patientIDToUpdate);
            System.out.println("1. Update Patient Name");
            System.out.println("2. Update Patient Gender");
            System.out.println("3. Update Patient Age");
            System.out.println("4. Update Patient Mobile Number");
            System.out.println("5. Update Patient Disease");
            System.out.println("6. Update Patient fees");
            System.out.println("7. Go Back");
            System.out.println("8. Exit");

            System.out.print("Enter your choice (1-8): ");
            int updateChoice = scanner.nextInt();
            scanner.nextLine();

            switch (updateChoice) {
                case 1 -> {
                    preparedStatement = connection.prepareStatement("UPDATE Hospital SET patientName = ? WHERE patientID = ?");
                    updateStringColumn(preparedStatement, "Enter updated patient name: ", patientIDToUpdate);
                }

                case 2 -> {
                    preparedStatement = connection.prepareStatement("UPDATE Hospital SET patientGender = ? WHERE patientID = ?");
                    updateCharColumn(preparedStatement, "Enter updated patient gender (M/F): ", patientIDToUpdate);
                }

                case 3 -> {
                    preparedStatement = connection.prepareStatement("UPDATE Hospital SET patientAge = ? WHERE patientID = ?");
                    updateIntColumn(preparedStatement, "Enter updated patient age: ", patientIDToUpdate);
                }

                case 4 -> {
                    preparedStatement = connection.prepareStatement("UPDATE Hospital SET patientMobileNo = ? WHERE patientID = ?");
                    updateLongColumn(preparedStatement, "Enter updated Mobile Number: ", patientIDToUpdate);
                }

                case 5 -> {
                    preparedStatement = connection.prepareStatement("UPDATE Hospital SET disease = ? WHERE patientID = ?");
                    updateStringColumn(preparedStatement, "Enter updated disease: ", patientIDToUpdate);
                }

                case 6 -> {
                    preparedStatement = connection.prepareStatement("UPDATE Hospital SET fees = ? WHERE patientID = ?");
                    updateDoubleColumn(preparedStatement, "Enter updated fees: ", patientIDToUpdate);
                }

                case 7 -> {
                    return;
                }

                case 8 -> System.exit(0);

                default -> System.out.println("Invalid choice for updating details.");
            }
            LocalDate localDate = LocalDate.now();
            Date lastModifiedDate =  Date.valueOf(localDate);
            preparedStatement = connection.prepareStatement("UPDATE Hospital SET lastModifiedDate = ? WHERE patientID = ?");
            preparedStatement.setDate(1,lastModifiedDate);

            System.out.println("Patient record updated successfully.");
            System.out.print("Do you want to continue? (y/n): ");
            continueChar = String.valueOf(scanner.next().charAt(0));
        } while (continueChar.equalsIgnoreCase("y"));
    }

    private void updateStringColumn(PreparedStatement preparedStatement, String prompt, int patientIDToUpdate) throws SQLException {
        System.out.print(prompt);
        Scanner scanner = new Scanner(System.in);
        String updatedValue = scanner.nextLine();
        preparedStatement.setString(1, updatedValue);
        preparedStatement.setInt(2, patientIDToUpdate);
        preparedStatement.executeUpdate();
//        scanner.close();
    }

    private void updateCharColumn(PreparedStatement preparedStatement, String prompt, int patientIDToUpdate) throws SQLException {
        System.out.print(prompt);
        Scanner scanner = new Scanner(System.in);
        char updatedValue = (scanner.next().charAt(0));
        preparedStatement.setString(1, String.valueOf(updatedValue).toUpperCase());
        preparedStatement.setInt(2, patientIDToUpdate);
        preparedStatement.executeUpdate();
//        scanner.close();
    }

    private void updateIntColumn(PreparedStatement preparedStatement, String prompt, int patientIDToUpdate) throws SQLException {
        System.out.print(prompt);
        Scanner scanner = new Scanner(System.in);
        int updatedValue = scanner.nextInt();
        scanner.nextLine();
        preparedStatement.setInt(1, updatedValue);
        preparedStatement.setInt(2, patientIDToUpdate);
        preparedStatement.executeUpdate();
//        scanner.close();

    }

    private void updateLongColumn(PreparedStatement preparedStatement, String prompt, int patientIDToUpdate) throws SQLException {
        System.out.print(prompt);
        Scanner scanner = new Scanner(System.in);
        long updatedValue = scanner.nextInt();
        scanner.nextLine();
        preparedStatement.setLong(1, updatedValue);
        preparedStatement.setInt(2, patientIDToUpdate);
        preparedStatement.executeUpdate();
//        scanner.close();
    }

    private void updateDoubleColumn(PreparedStatement preparedStatement, String prompt, int patientIDToUpdate) throws SQLException {
        System.out.print(prompt);
        Scanner scanner = new Scanner(System.in);
        double updatedValue = scanner.nextDouble();
        scanner.nextLine();
        preparedStatement.setDouble(1, updatedValue);
        preparedStatement.setInt(2, patientIDToUpdate);
        preparedStatement.executeUpdate();
//        scanner.close();
    }
}