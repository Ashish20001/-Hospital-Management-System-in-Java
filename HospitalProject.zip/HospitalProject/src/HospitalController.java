import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;

public class HospitalController {
    private final Connection connection;
    private final Scanner scanner;

    public HospitalController(Connection connection) {
        this.connection = connection;
        this.scanner = new Scanner(System.in);
    }

    public void processChoice(int choice) {
        switch (choice) {
            case 1 -> addPatientRecord();
            case 2 -> deletePatientRecord();
            case 3 -> updatePatientInformation();
            case 4 -> viewAllPatients();
            case 5 -> searchForPatient();
            case 6 -> findDoctor();
            case 7 -> changeDoctor();
            case 8 -> findPatientWithSameDisease();
            case 9 -> discountInFees();
            case 10 -> System.exit(0);
            default -> System.out.println("Invalid choice! Please enter a valid option.");
        }
    }

    private void addPatientRecord() {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "INSERT INTO Hospital(patientName, patientGender, patientAge, patientMobileNo, disease, doctorName, fees, lastModifiedDate) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            System.out.println("Enter patient name: ");
            String patientName = scanner.nextLine();

            System.out.println("Enter patient gender (M/F): ");
            char patientGender = scanner.next().toUpperCase().charAt(0);

            System.out.println("Enter patient age: ");
            int patientAge = scanner.nextInt();
            scanner.nextLine();

            System.out.println("Enter patient mobile number : ");
            long patientMobileNo = scanner.nextLong();
            scanner.nextLine();

            System.out.println("Enter disease: ");
            String disease = scanner.nextLine();

            System.out.println("Enter doctor name: ");
            String doctorName = scanner.nextLine();

            System.out.println("Enter fees: ");
            double fees = scanner.nextDouble();
            scanner.nextLine();

            LocalDate localDate = LocalDate.now();
            Date lastModifiedDate =  Date.valueOf(localDate);

            preparedStatement.setString(1, patientName);
            preparedStatement.setString(2, Character.toString(patientGender));
            preparedStatement.setInt(3, patientAge);
            preparedStatement.setLong(4, patientMobileNo);
            preparedStatement.setString(5, disease);
            preparedStatement.setString(6, doctorName);
            preparedStatement.setDouble(7, fees);
            preparedStatement.setDate(8, lastModifiedDate);

            preparedStatement.executeUpdate();
            System.out.println("Patient record added successfully.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void deletePatientRecord() {
        try {
            System.out.println("Enter patient ID to be deleted: ");
            int patientID = scanner.nextInt();
            scanner.nextLine();
            if (isPatientExists(connection, patientID) < 1) {
                System.out.println("The patient with ID " + patientID + " Does NOT Exist.");
                return;
            }
            PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM Hospital WHERE patientID = ?");
            preparedStatement.setInt(1, patientID);
            preparedStatement.executeUpdate();
            System.out.println("Patient record deleted successfully.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void updatePatientInformation() {
        try {
            System.out.println("Enter patient ID to be Updated: ");
            int patientID = scanner.nextInt();
            scanner.nextLine();
            if (isPatientExists(connection, patientID) < 1) {
                System.out.println("The patient with ID " + patientID + " Does NOT Exist.");
                return;
            }
            UpdatePatient updatePatient = new UpdatePatient();
            updatePatient.update(connection, patientID);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void viewAllPatients() {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Hospital ORDER BY patientId");
            ResultSet resultSet = preparedStatement.executeQuery();

            int rowCount = 0;
            while (resultSet.next()) {
                printPatientData(resultSet);
                rowCount = resultSet.getRow();
            }

            System.out.println("All patient records retrieved : " + rowCount);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void searchForPatient() {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Hospital WHERE patientName = ?");
            System.out.println("Enter patient Name to search: ");
            String patientNameToSearch = scanner.nextLine();
            preparedStatement.setString(1, patientNameToSearch);
            ResultSet resultSet = preparedStatement.executeQuery();

            int rowCount = 0;
            while (resultSet.next()) {
                printPatientData(resultSet);
                rowCount = resultSet.getRow();
            }

            System.out.println("Patient record retrieved successfully : " + rowCount);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


    private void findDoctor() {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Hospital WHERE doctorName = ? ORDER BY patientId");
            System.out.print("Enter doctor name to find patients: ");
            String doctorName = scanner.nextLine();
            preparedStatement.setString(1, doctorName);
            ResultSet resultSet = preparedStatement.executeQuery();

            int rowCount = 0;
            while (resultSet.next()) {
                printPatientData(resultSet);
                rowCount = resultSet.getRow();
            }

            System.out.println("Patients for Doctor '" + doctorName + "' found successfully : " + rowCount);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void changeDoctor() {
        try {

            System.out.print("Enter patient ID to change doctor: ");
            int patientID = scanner.nextInt();
            scanner.nextLine();
            if (isPatientExists(connection, patientID) < 1) {
                System.out.println("The patient with ID " + patientID + " Does NOT Exist.");
                return;
            }
            PreparedStatement preparedStatement = connection.prepareStatement("UPDATE Hospital SET doctorName = ? WHERE patientID = ?");
            System.out.print("Enter new doctor name: ");
            String newDoctorName = scanner.nextLine();

            preparedStatement.setString(1, newDoctorName);
            preparedStatement.setInt(2, patientID);
            preparedStatement.executeUpdate();

            System.out.println("Doctor changed successfully for patient ID " + patientID + ".");
        } catch (Exception e) {
            if (e instanceof InputMismatchException){
                System.out.println("Invalid Input");
            }
            System.out.println(e.getMessage());
        }
    }

    private void findPatientWithSameDisease() {
        try {
            System.out.print("Enter disease to find patients: ");
            String disease = scanner.nextLine();
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Hospital WHERE disease = ?");
            preparedStatement.setString(1, disease);
            ResultSet resultSet = preparedStatement.executeQuery();

            int rowCount = 0;
            while (resultSet.next()) {
                printPatientData(resultSet);
                rowCount = resultSet.getRow();
            }

            System.out.println("Patients with disease '" + disease + "' found successfully : " + rowCount);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void discountInFees() {
        System.out.print("Enter patient ID for discount: ");
        int patientID = scanner.nextInt();
        if (isPatientExists(connection, patientID) < 1) {
            System.out.println("The patient with ID " + patientID + " Does NOT Exist.");
            return;
        }
        System.out.print("Enter discount amount: ");
        double discount = scanner.nextDouble();

        try (PreparedStatement preparedStatement = connection.prepareStatement(
                "UPDATE Hospital SET fees = GREATEST(0, fees - ?), lastModifiedDate = ? WHERE patientID = ?")) {
            preparedStatement.setDouble(1, discount);

            LocalDate localDate = LocalDate.now();
            Date lastModifiedDate =  Date.valueOf(localDate);
            preparedStatement.setDate(2,lastModifiedDate);

            preparedStatement.setInt(3, patientID);
            preparedStatement.executeUpdate();

            System.out.println("Discount applied successfully for patient ID " + patientID + ".");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void printPatientData(ResultSet resultSet) {
        try {
//            Hospital record = new Hospital(
//                            (resultSet.getInt("patientID")),
//                            (resultSet.getString("patientName")),
//                            (resultSet.getString("patientGender")).charAt(0),
//                            (resultSet.getInt("patientAge")),
//                            (resultSet.getLong("patientMobileNo")),
//                            (resultSet.getString("disease")),
//                            (resultSet.getString("doctorName")),
//                            (resultSet.getDouble("fees"))
//            );
//
//            System.out.println(record.toString());
//            System.out.println(
//                    "PatientID: " + resultSet.getInt("patientID") +
//                            ", Name: " + resultSet.getString("patientName") +
//                            ", Gender: " + resultSet.getString("patientGender") +
//                            ", Age: " + resultSet.getInt("patientAge") +
//                            ", Mobile Number: " + resultSet.getLong("patientMobileNo") +
//                            ", Disease: " + resultSet.getString("disease") +
//                            ", Doctor: " + resultSet.getString("doctorName") +
//                            ", Fees: " + resultSet.getDouble("fees") +
//                            ", Registered Date: " + resultSet.getDate("registeredDate")
//            );

            System.out.println(String.format(
                    "PatientID: %-3d | Name: %-20s | Gender: %-2s | Age:  %-3d | Mobile Number: %-10d | Disease: %-25s | Doctor: %-20s | Fees: %-10.2f | Registered Date: %11s | Last Updated: %s",
                    resultSet.getInt("patientID"),
                    resultSet.getString("patientName"),
                    resultSet.getString("patientGender"),
                    resultSet.getInt("patientAge"),
                    resultSet.getLong("patientMobileNo"),
                    resultSet.getString("disease"),
                    resultSet.getString("doctorName"),
                    resultSet.getDouble("fees"),
                    resultSet.getDate("registeredDate"),
                    resultSet.getDate("lastModifiedDate")
            ));

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private int isPatientExists(Connection connection, int patientIDToUpdate) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from Hospital WHERE patientId = ? ");
            preparedStatement.setInt(1, patientIDToUpdate);
            ResultSet resultSet = preparedStatement.executeQuery();
            int rowCount = 0;
            while (resultSet.next()) {
                rowCount = resultSet.getRow();
            }
            return rowCount;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
}
